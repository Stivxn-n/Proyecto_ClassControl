-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: classcontrol
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `actividades`
--

LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
INSERT INTO `actividades` VALUES (1,10001,'Taller HTML5 y CSS3','Construcción de página web estática usando etiquetas semánticas',1),(2,10002,'Consumo de API REST con Fetch','Conectar una SPA a un endpoint y mostrar datos en pantalla',2),(3,10003,'Diseño de BD Biblioteca','Modelar el esquema relacional de una biblioteca virtual',3),(4,10004,'Consultas avanzadas MySQL','Ejecutar JOINs, subconsultas y funciones de agregación',4),(5,10005,'Configuración de red VLAN','Segmentar una red corporativa con VLANs en Cisco Packet Tracer',5),(6,10006,'Diagnóstico de red con Wireshark','Capturar y analizar tráfico para detectar anomalías',6),(7,10007,'Implementar HTTPS en servidor','Instalar certificado SSL/TLS en servidor Apache',7),(8,10008,'Control de motor con Arduino','Programar un microcontrolador para controlar velocidad de motor DC',8),(9,10009,'Planificación de sprint','Definir backlog y sprints para proyecto de desarrollo',9);
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ambientes`
--

LOCK TABLES `ambientes` WRITE;
/*!40000 ALTER TABLE `ambientes` DISABLE KEYS */;
INSERT INTO `ambientes` VALUES (1,'Aula 101',30,1),(2,'Laboratorio Redes',25,1),(3,'Aula 202',28,2),(4,'Aula 301',30,2),(5,'Lab. Sistemas',20,3),(6,'Aula 103',32,3),(7,'Sala Multimedia',24,1),(8,'Aula 204',30,2),(9,'Lab. Software',22,1);
/*!40000 ALTER TABLE `ambientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `competencias`
--

LOCK TABLES `competencias` WRITE;
/*!40000 ALTER TABLE `competencias` DISABLE KEYS */;
INSERT INTO `competencias` VALUES (1,220046,'Construir aplicaciones web',1),(2,220047,'Gestionar bases de datos',2),(3,220048,'Desarrollar interfaces de usuario',3),(4,220049,'Administrar redes de datos',4),(5,220050,'Implementar seguridad en redes',5),(6,220051,'Programar microcontroladores',8),(7,220052,'Aplicar metodologías ágiles',10),(8,220053,'Gestionar proyectos de software',11),(9,220054,'Integrar sistemas de información',12);
/*!40000 ALTER TABLE `competencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estado`
--

LOCK TABLES `estado` WRITE;
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` VALUES (1,'Activo'),(2,'Inactivo'),(3,'En ejecución'),(4,'Finalizado');
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `etapa`
--

LOCK TABLES `etapa` WRITE;
/*!40000 ALTER TABLE `etapa` DISABLE KEYS */;
INSERT INTO `etapa` VALUES (1,'Lectiva'),(2,'Productiva');
/*!40000 ALTER TABLE `etapa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ficha`
--

LOCK TABLES `ficha` WRITE;
/*!40000 ALTER TABLE `ficha` DISABLE KEYS */;
INSERT INTO `ficha` VALUES (1,'2879650','2024-08-05','2026-08-04',28,1,1,1,2,1,3,1),(2,'2879651','2024-08-05','2026-08-04',25,2,2,1,2,2,3,1),(3,'2912340','2025-02-03','2027-02-02',30,1,1,1,2,1,3,1),(4,'2831100','2023-10-02','2024-10-01',22,3,2,1,1,3,4,2),(5,'2956780','2025-02-03','2026-02-02',18,4,3,1,1,2,3,1),(6,'2765430','2024-02-05','2025-02-04',20,2,1,2,2,1,4,2),(7,'3001230','2025-08-04','2027-08-03',26,1,2,1,2,3,1,1);
/*!40000 ALTER TABLE `ficha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `jornada`
--

LOCK TABLES `jornada` WRITE;
/*!40000 ALTER TABLE `jornada` DISABLE KEYS */;
INSERT INTO `jornada` VALUES (1,'Mañana'),(2,'Tarde'),(3,'Noche'),(4,'Mixta');
/*!40000 ALTER TABLE `jornada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `modalidad`
--

LOCK TABLES `modalidad` WRITE;
/*!40000 ALTER TABLE `modalidad` DISABLE KEYS */;
INSERT INTO `modalidad` VALUES (1,'Presencial'),(2,'Virtual'),(3,'A distancia');
/*!40000 ALTER TABLE `modalidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `nivel_formacion`
--

LOCK TABLES `nivel_formacion` WRITE;
/*!40000 ALTER TABLE `nivel_formacion` DISABLE KEYS */;
INSERT INTO `nivel_formacion` VALUES (1,'Técnico'),(2,'Tecnólogo'),(3,'Especialización Tecnológica');
/*!40000 ALTER TABLE `nivel_formacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `programacion_instructores`
--

LOCK TABLES `programacion_instructores` WRITE;
/*!40000 ALTER TABLE `programacion_instructores` DISABLE KEYS */;
INSERT INTO `programacion_instructores` VALUES (1,'Lógica de programación','2025-04-28','2025-07-18','LUN','07:00:00','11:00:00',1,1,1,2,3),(2,'Base de datos I','2025-04-29','2025-07-19','MAR','07:00:00','11:00:00',3,1,7,2,3),(3,'Programación web','2025-07-21','2025-10-10','MIE','07:00:00','11:00:00',1,1,1,3,1),(4,'Redes LAN','2025-04-30','2025-07-20','JUE','13:00:00','17:00:00',2,2,2,2,3),(5,'Seguridad informática','2025-05-01','2025-07-21','VIE','13:00:00','17:00:00',6,2,3,2,3),(6,'Redes WAN','2025-07-22','2025-10-11','LUN','13:00:00','17:00:00',2,2,4,3,1),(7,'Electrónica digital','2025-05-02','2025-07-22','MAR','13:00:00','17:00:00',5,3,5,2,3),(8,'Microcontroladores','2025-07-23','2025-10-12','MIE','13:00:00','17:00:00',5,3,6,3,1),(9,'Automatización','2025-10-13','2025-12-19','JUE','13:00:00','17:00:00',5,3,6,4,1),(10,'Desarrollo de software','2025-05-05','2025-07-25','VIE','07:00:00','11:00:00',7,4,8,2,3),(11,'Metodologías ágiles','2025-07-28','2025-10-17','LUN','07:00:00','11:00:00',7,4,9,3,1),(12,'Proyecto final de ficha','2025-10-14','2025-12-18','MAR','07:00:00','11:00:00',3,4,7,4,1);
/*!40000 ALTER TABLE `programacion_instructores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `programas`
--

LOCK TABLES `programas` WRITE;
/*!40000 ALTER TABLE `programas` DISABLE KEYS */;
INSERT INTO `programas` VALUES (1,228106,'Análisis y Desarrollo de Software'),(2,233585,'Gestión de Redes de Datos'),(3,134217,'Técnico en Programación de Software'),(4,122317,'Técnico en Sistemas');
/*!40000 ALTER TABLE `programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `resultado_aprendizaje`
--

LOCK TABLES `resultado_aprendizaje` WRITE;
/*!40000 ALTER TABLE `resultado_aprendizaje` DISABLE KEYS */;
INSERT INTO `resultado_aprendizaje` VALUES (1,330101,'Crear páginas web responsivas',1),(2,330102,'Implementar servicios REST',1),(3,330201,'Diseñar modelo entidad-relación',2),(4,330202,'Ejecutar consultas SQL avanzadas',2),(5,330301,'Configurar enrutadores y switches',4),(6,330302,'Diagnosticar fallas en redes',4),(7,330401,'Aplicar cifrado en comunicaciones',5),(8,330501,'Programar PLC básico',6),(9,330601,'Planificar sprints con Scrum',7);
/*!40000 ALTER TABLE `resultado_aprendizaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador'),(3,'Aprendiz'),(2,'Instructor');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `sede`
--

LOCK TABLES `sede` WRITE;
/*!40000 ALTER TABLE `sede` DISABLE KEYS */;
INSERT INTO `sede` VALUES (2,'Sede Norte'),(1,'Sede Principal Bogotá'),(3,'Sede Sur');
/*!40000 ALTER TABLE `sede` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_documento`
--

LOCK TABLES `tipo_documento` WRITE;
/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (1,'Cédula de Ciudadanía'),(3,'Cédula de Extranjería'),(4,'Pasaporte'),(2,'Tarjeta de Identidad');
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_vinculacion`
--

LOCK TABLES `tipo_vinculacion` WRITE;
/*!40000 ALTER TABLE `tipo_vinculacion` DISABLE KEYS */;
INSERT INTO `tipo_vinculacion` VALUES (3,'Aprendiz SENA'),(2,'Contrato'),(1,'Planta');
/*!40000 ALTER TABLE `tipo_vinculacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trimestre`
--

LOCK TABLES `trimestre` WRITE;
/*!40000 ALTER TABLE `trimestre` DISABLE KEYS */;
INSERT INTO `trimestre` VALUES (1,1,'Primer Trimestre 2025','2025-02-03','2025-04-25'),(2,2,'Segundo Trimestre 2025','2025-04-28','2025-07-18'),(3,3,'Tercer Trimestre 2025','2025-07-21','2025-10-10'),(4,4,'Cuarto Trimestre 2025','2025-10-13','2025-12-19');
/*!40000 ALTER TABLE `trimestre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Carlos Andrés','Ramírez Torres','10245678','1985-03-15','c.ramirez@sena.edu.co','3101234567','Cra 7 #45-23 Bogotá','cramirez','Especialización','Ingeniero de Sistemas','carlos123','2023-01-15',1,2,1,1),(2,'María Fernanda','López Gómez','52134987','1988-07-22','m.lopez@sena.edu.co','3152345678','Calle 80 #12-34 Bogotá','mlopez','Maestría','Ingeniera de Telecomunicaciones','maria123','2023-02-10',1,2,1,1),(3,'Jorge Luis','Martínez Peña','79834512','1980-11-05','j.martinez@sena.edu.co','3203456789','Av. 68 #23-11 Bogotá','jmartinez','Maestría','Ingeniero Electrónico','jorge123','2023-03-05',1,2,1,2),(4,'Paola Andrea','Suárez Vargas','43987612','1990-06-18','p.suarez@sena.edu.co','3174567890','Calle 13 #34-56 Bogotá','psuarez','Especialización','Desarrolladora de Software','paola123','2024-01-08',1,2,1,2),(5,'Ricardo','Ospina Herrera','11223344','1975-09-30','r.ospina@sena.edu.co','3005678901','Cra 15 #67-89 Bogotá','rospina','Maestría','Administrador de Empresas','ricardo123','2022-08-01',1,1,1,1),(6,'Sandra Patricia','Morales Cárdenas','39876543','1978-04-12','s.morales@sena.edu.co','3016789012','Calle 26 #45-12 Bogotá','smorales','Especialización','Contadora Pública','sandra123','2022-08-01',1,1,1,1),(7,'Andrés Felipe','Cárdenas Ríos','80123456','1982-12-25','a.cardenas@sena.edu.co','3027890123','Av. NQS #89-34 Bogotá','acardenas','Maestría','Ingeniero Industrial','andres123','2023-06-15',1,1,1,1),(8,'Juan David','García Niño','1007123456','2003-05-14','jd.garcia@aprendiz.sena.edu.co','3112345001','Cra 22 #11-05 Bogotá','jgarcia','Bachillerato','Estudiante','juan123','2024-08-05',1,3,2,3),(9,'Valentina','Reyes Castillo','1015678902','2004-02-28','v.reyes@aprendiz.sena.edu.co','3123456002','Calle 60 #18-22 Bogotá','vreyes','Bachillerato','Estudiante','valentina123','2024-08-05',1,3,2,3),(10,'Miguel Angel','Torres Herrera','1006789103','2002-09-17','m.torres@aprendiz.sena.edu.co','3134567003','Cra 50 #25-30 Bogotá','mtorres','Bachillerato','Estudiante','miguel123','2024-08-05',1,3,2,3),(11,'Laura Sofía','Pineda Mora','1012890204','2003-11-03','l.pineda@aprendiz.sena.edu.co','3145678004','Calle 45 #7-14 Bogotá','lpineda','Bachillerato','Estudiante','laura123','2024-08-05',1,3,2,3),(12,'Sebastián','Vargas Ortiz','1018901305','2004-07-19','s.vargas@aprendiz.sena.edu.co','3156789005','Av. Boyacá #34-67 Bogotá','svargas','Bachillerato','Estudiante','sebastian123','2025-02-03',1,3,2,3),(13,'Diana Carolina','Salazar Vega','1022012406','2005-01-08','d.salazar@aprendiz.sena.edu.co','3167890006','Calle 127 #15-33 Bogotá','dsalazar','Bachillerato','Estudiante','diana123','2025-02-03',1,3,2,3),(14,'Felipe Andrés','Mendoza Castro','1025123507','2003-04-25','f.mendoza@aprendiz.sena.edu.co','3178901007','Cra 30 #53-21 Bogotá','fmendoza','Bachillerato','Estudiante','felipe123','2025-02-03',1,3,2,3);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `vinculacionlaboral`
--

LOCK TABLES `vinculacionlaboral` WRITE;
/*!40000 ALTER TABLE `vinculacionlaboral` DISABLE KEYS */;
INSERT INTO `vinculacionlaboral` VALUES (1,'Contrato instructoría planta','CONT-2023-001','2023-01-15','2025-01-14',1),(2,'Contrato instructoría planta','CONT-2023-002','2023-02-10','2025-02-09',2),(3,'Contrato de prestación','CONT-2023-003','2023-03-05','2024-03-04',3),(4,'Contrato de prestación','CONT-2024-004','2024-01-08','2025-01-07',4),(5,'Nombramiento planta','NOMB-2022-001','2022-08-01','2026-07-31',5),(6,'Nombramiento planta','NOMB-2022-002','2022-08-01','2026-07-31',6),(7,'Contrato administrativo','CONT-2023-007','2023-06-15','2025-06-14',7);
/*!40000 ALTER TABLE `vinculacionlaboral` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-05  8:23:05
