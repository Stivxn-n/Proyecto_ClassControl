-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: classcontrol
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actividades`
--

DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades` (
  `id_actividades` int NOT NULL AUTO_INCREMENT,
  `codigoActividad` int NOT NULL,
  `nombre_Act` varchar(100) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `Resultado_aprendizaje_id_resultado_aprendizaje` int NOT NULL,
  PRIMARY KEY (`id_actividades`),
  UNIQUE KEY `codigoActividad_UNIQUE` (`codigoActividad`),
  KEY `fk_Actividades_Resultado_aprendizaje1_idx` (`Resultado_aprendizaje_id_resultado_aprendizaje`),
  CONSTRAINT `fk_Actividades_Resultado_aprendizaje1` FOREIGN KEY (`Resultado_aprendizaje_id_resultado_aprendizaje`) REFERENCES `resultado_aprendizaje` (`id_resultado_aprendizaje`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ambientes`
--

DROP TABLE IF EXISTS `ambientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambientes` (
  `id_ambientes` int NOT NULL AUTO_INCREMENT,
  `descripcion_Ambiente` varchar(45) NOT NULL,
  `capacidad` int NOT NULL,
  `Sede_id_sede` int NOT NULL,
  PRIMARY KEY (`id_ambientes`),
  UNIQUE KEY `descripcion_Ambiente_UNIQUE` (`descripcion_Ambiente`),
  KEY `fk_Ambientes_Sede1_idx` (`Sede_id_sede`),
  CONSTRAINT `fk_Ambientes_Sede1` FOREIGN KEY (`Sede_id_sede`) REFERENCES `sede` (`id_sede`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `competencias`
--

DROP TABLE IF EXISTS `competencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `competencias` (
  `id_competencias` int NOT NULL AUTO_INCREMENT,
  `codigoCompetencias` int NOT NULL,
  `descripcionCompetencias` varchar(45) NOT NULL,
  `Programacion_Instructores_id_programacion_Instructores` int NOT NULL,
  PRIMARY KEY (`id_competencias`),
  UNIQUE KEY `codigoCompetencias_UNIQUE` (`codigoCompetencias`),
  KEY `fk_Competencias_Programacion_Instructores1_idx` (`Programacion_Instructores_id_programacion_Instructores`),
  CONSTRAINT `fk_Competencias_Programacion_Instructores1` FOREIGN KEY (`Programacion_Instructores_id_programacion_Instructores`) REFERENCES `programacion_instructores` (`id_programacion_Instructores`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado` (
  `id_estado` int NOT NULL AUTO_INCREMENT,
  `descripcion_Estado` varchar(45) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etapa`
--

DROP TABLE IF EXISTS `etapa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etapa` (
  `id_etapa` int NOT NULL AUTO_INCREMENT,
  `descripcion_Etapa` varchar(45) NOT NULL,
  PRIMARY KEY (`id_etapa`),
  UNIQUE KEY `descripcion_Etapa_UNIQUE` (`descripcion_Etapa`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ficha`
--

DROP TABLE IF EXISTS `ficha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ficha` (
  `id_ficha` int NOT NULL AUTO_INCREMENT,
  `codigo_ficha` varchar(45) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `cantidad_aprendices` int NOT NULL,
  `Programas_idProgramas` int NOT NULL,
  `Jornada_id_jornada` int NOT NULL,
  `Modalidad_id_modalidad` int NOT NULL,
  `Nivel_formacion_id_nivel_formacion` int NOT NULL,
  `Sede_id_sede` int NOT NULL,
  `Estado_id_estado` int NOT NULL,
  `Etapa_id_etapa` int NOT NULL,
  PRIMARY KEY (`id_ficha`),
  KEY `fk_Ficha_Programas1_idx` (`Programas_idProgramas`),
  KEY `fk_Ficha_Jornada1_idx` (`Jornada_id_jornada`),
  KEY `fk_Ficha_Modalidad1_idx` (`Modalidad_id_modalidad`),
  KEY `fk_Ficha_Nivel_formacion1_idx` (`Nivel_formacion_id_nivel_formacion`),
  KEY `fk_Ficha_Sede1_idx` (`Sede_id_sede`),
  KEY `fk_Ficha_Estado1_idx` (`Estado_id_estado`),
  KEY `fk_Ficha_Etapa1_idx` (`Etapa_id_etapa`),
  CONSTRAINT `fk_Ficha_Estado1` FOREIGN KEY (`Estado_id_estado`) REFERENCES `estado` (`id_estado`),
  CONSTRAINT `fk_Ficha_Etapa1` FOREIGN KEY (`Etapa_id_etapa`) REFERENCES `etapa` (`id_etapa`),
  CONSTRAINT `fk_Ficha_Jornada1` FOREIGN KEY (`Jornada_id_jornada`) REFERENCES `jornada` (`id_jornada`),
  CONSTRAINT `fk_Ficha_Modalidad1` FOREIGN KEY (`Modalidad_id_modalidad`) REFERENCES `modalidad` (`id_modalidad`),
  CONSTRAINT `fk_Ficha_Nivel_formacion1` FOREIGN KEY (`Nivel_formacion_id_nivel_formacion`) REFERENCES `nivel_formacion` (`id_nivel_formacion`),
  CONSTRAINT `fk_Ficha_Programas1` FOREIGN KEY (`Programas_idProgramas`) REFERENCES `programas` (`idProgramas`),
  CONSTRAINT `fk_Ficha_Sede1` FOREIGN KEY (`Sede_id_sede`) REFERENCES `sede` (`id_sede`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jornada`
--

DROP TABLE IF EXISTS `jornada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jornada` (
  `id_jornada` int NOT NULL AUTO_INCREMENT,
  `descripcion_Jornada` varchar(45) NOT NULL,
  PRIMARY KEY (`id_jornada`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modalidad`
--

DROP TABLE IF EXISTS `modalidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modalidad` (
  `id_modalidad` int NOT NULL AUTO_INCREMENT,
  `descripcion_Modalidad` varchar(45) NOT NULL,
  PRIMARY KEY (`id_modalidad`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivel_formacion`
--

DROP TABLE IF EXISTS `nivel_formacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nivel_formacion` (
  `id_nivel_formacion` int NOT NULL AUTO_INCREMENT,
  `descripcion_Nivel_Formacion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_nivel_formacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `programacion_instructores`
--

DROP TABLE IF EXISTS `programacion_instructores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programacion_instructores` (
  `id_programacion_Instructores` int NOT NULL AUTO_INCREMENT,
  `Observaciones` varchar(45) NOT NULL,
  `fecha_inicial_Prog` date NOT NULL,
  `fecha_fin_Prog` date NOT NULL,
  `diasSemana` enum('LUN','MAR','MIE','JUE','VIE','SAB') NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `Ficha_id_ficha` int NOT NULL,
  `Usuarios_id_usuarios` int NOT NULL,
  `Ambientes_id_ambientes` int NOT NULL,
  `Trimestre_id_trimestre` int NOT NULL,
  `Estado_id_estado` int NOT NULL,
  PRIMARY KEY (`id_programacion_Instructores`),
  KEY `fk_Programacion_Instructores_Ficha1_idx` (`Ficha_id_ficha`),
  KEY `fk_Programacion_Instructores_Usuarios1_idx` (`Usuarios_id_usuarios`),
  KEY `fk_Programacion_Instructores_Ambientes1_idx` (`Ambientes_id_ambientes`),
  KEY `fk_Programacion_Instructores_Trimestre1_idx` (`Trimestre_id_trimestre`),
  KEY `fk_Programacion_Instructores_Estado1_idx` (`Estado_id_estado`),
  CONSTRAINT `fk_Programacion_Instructores_Ambientes1` FOREIGN KEY (`Ambientes_id_ambientes`) REFERENCES `ambientes` (`id_ambientes`),
  CONSTRAINT `fk_Programacion_Instructores_Estado1` FOREIGN KEY (`Estado_id_estado`) REFERENCES `estado` (`id_estado`),
  CONSTRAINT `fk_Programacion_Instructores_Ficha1` FOREIGN KEY (`Ficha_id_ficha`) REFERENCES `ficha` (`id_ficha`),
  CONSTRAINT `fk_Programacion_Instructores_Trimestre1` FOREIGN KEY (`Trimestre_id_trimestre`) REFERENCES `trimestre` (`id_trimestre`),
  CONSTRAINT `fk_Programacion_Instructores_Usuarios1` FOREIGN KEY (`Usuarios_id_usuarios`) REFERENCES `usuarios` (`id_usuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `programas`
--

DROP TABLE IF EXISTS `programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programas` (
  `idProgramas` int NOT NULL AUTO_INCREMENT,
  `codigo_programa` int NOT NULL,
  `nombre_programa` varchar(45) NOT NULL,
  PRIMARY KEY (`idProgramas`),
  UNIQUE KEY `codigo_programa_UNIQUE` (`codigo_programa`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resultado_aprendizaje`
--

DROP TABLE IF EXISTS `resultado_aprendizaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resultado_aprendizaje` (
  `id_resultado_aprendizaje` int NOT NULL AUTO_INCREMENT,
  `codigoResultadoAp` int NOT NULL,
  `descripcionResul` varchar(45) NOT NULL,
  `Competencias_id_competencias` int NOT NULL,
  PRIMARY KEY (`id_resultado_aprendizaje`),
  UNIQUE KEY `codigoResultadoAp_UNIQUE` (`codigoResultadoAp`),
  KEY `fk_Resultado_aprendizaje_Competencias1_idx` (`Competencias_id_competencias`),
  CONSTRAINT `fk_Resultado_aprendizaje_Competencias1` FOREIGN KEY (`Competencias_id_competencias`) REFERENCES `competencias` (`id_competencias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id_roles` int NOT NULL AUTO_INCREMENT,
  `descripcion_Roles` varchar(45) NOT NULL,
  PRIMARY KEY (`id_roles`),
  UNIQUE KEY `descripcion_Roles_UNIQUE` (`descripcion_Roles`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sede`
--

DROP TABLE IF EXISTS `sede`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sede` (
  `id_sede` int NOT NULL AUTO_INCREMENT,
  `nombre_sede` varchar(45) NOT NULL,
  PRIMARY KEY (`id_sede`),
  UNIQUE KEY `nombre_sede_UNIQUE` (`nombre_sede`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_documento` (
  `id_tipo_Documento` int NOT NULL AUTO_INCREMENT,
  `descripcion_TipoDoc` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_Documento`),
  UNIQUE KEY `descripcion_TipoDoc_UNIQUE` (`descripcion_TipoDoc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipo_vinculacion`
--

DROP TABLE IF EXISTS `tipo_vinculacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_vinculacion` (
  `id_tipo_vinculacion` int NOT NULL AUTO_INCREMENT,
  `descripcion_vinculacion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_vinculacion`),
  UNIQUE KEY `descripcion_vinculacion_UNIQUE` (`descripcion_vinculacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trimestre`
--

DROP TABLE IF EXISTS `trimestre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trimestre` (
  `id_trimestre` int NOT NULL AUTO_INCREMENT,
  `num_trimestre` int NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  PRIMARY KEY (`id_trimestre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuarios` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `identificacion` varchar(45) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `telefono` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `Roles_id_roles` int NOT NULL,
  `Tipo_Documento_id_tipo_Documento` int NOT NULL,
  `Tipo_vinculacion_id_tipo_vinculacion` int NOT NULL,
  `nivel_educativo` varchar(100) DEFAULT NULL,
  `profesion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_usuarios`),
  UNIQUE KEY `identificacion_UNIQUE` (`identificacion`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `fk_Usuarios_Roles_idx` (`Roles_id_roles`),
  KEY `fk_Usuarios_Tipo_Documento1_idx` (`Tipo_Documento_id_tipo_Documento`),
  KEY `fk_Usuarios_Tipo_vinculacion1_idx` (`Tipo_vinculacion_id_tipo_vinculacion`),
  CONSTRAINT `fk_Usuarios_Roles` FOREIGN KEY (`Roles_id_roles`) REFERENCES `roles` (`id_roles`),
  CONSTRAINT `fk_Usuarios_Tipo_Documento1` FOREIGN KEY (`Tipo_Documento_id_tipo_Documento`) REFERENCES `tipo_documento` (`id_tipo_Documento`),
  CONSTRAINT `fk_Usuarios_Tipo_vinculacion1` FOREIGN KEY (`Tipo_vinculacion_id_tipo_vinculacion`) REFERENCES `tipo_vinculacion` (`id_tipo_vinculacion`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vinculacionlaboral`
--

DROP TABLE IF EXISTS `vinculacionlaboral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vinculacionlaboral` (
  `idvinculacionLaboral` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `numeroContrato` varchar(45) NOT NULL,
  `fechaInIcio` date NOT NULL,
  `fechafin` date NOT NULL,
  `Usuarios_id_usuarios` int NOT NULL,
  PRIMARY KEY (`idvinculacionLaboral`),
  UNIQUE KEY `numeroContrato_UNIQUE` (`numeroContrato`),
  KEY `fk_VinculacionLaboral_Usuarios1_idx` (`Usuarios_id_usuarios`),
  CONSTRAINT `fk_VinculacionLaboral_Usuarios1` FOREIGN KEY (`Usuarios_id_usuarios`) REFERENCES `usuarios` (`id_usuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:42:07
